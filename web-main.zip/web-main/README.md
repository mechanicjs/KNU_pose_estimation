# Capture
![실행화면](https://user-images.githubusercontent.com/33569961/116715481-b901c900-aa11-11eb-82a1-916a31f56619.JPG)

